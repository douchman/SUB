package com.example.janus.cardgame;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.graphics.Color;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.Slide;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    int open_cnt=0;
    // 뒤집을 수 있는 카드를 제어하기 위한 변수
    // 0  : 현재 오픈한 카드 없음
    // 1  : 현재 오픈한 카드 있음

    int open_card=0, chk_card=0;
    // 내부클래스에서 사용하고
    // 카드 매칭 확인을 위한 변수

    public class Card {
        final private ImageView img_front;
        final private ImageView img_back;
        // 뒷면이 보이는 상태
        int tag = 0;
        // 뒤집은 카드가 같은지 확인을 위한 고유 태그
        int card_state = 0;
        // 현재 카드가 어떤 상태인지 확인을 위한 값
        //  0: 뒷면( 물음표 ) 1:앞면  2: 매칭이 완료된 상태(done)

        public Card(ImageView tmp, ImageView tmp2, int t) {
            this.img_front = tmp;
            this.img_back = tmp2;
            this.tag = t;
        }

        public void setTag(int t) {
            this.tag = t;
        }
        public int getTag()
        {
            return tag;
        }
    }
    public class CardThread extends Thread
    {

    }
    public void shuffle(Card [] c)
    {
        int [] index = new int[30];
        int [] imgID = new int[30];
        Random r = new Random();

        for ( int i=0; i<30; i++) {
            index[i] = r.nextInt(30);
            for (int j = 0; j < i; j++) {
                if (index[i] == index[j] )
                    i--;
            }
            String resName = "@drawable/img" + index[i];
            imgID[i] = getResources().getIdentifier(resName, "drawable", getPackageName());
            //int ImgID = getResources().getIdentifier(resName, "drawable", getPackageName());
            // c[index[i]].img_front.setImageResource(imgID[i]);
        }

        for (int i=0; i<30; i++)
        {
            if ( i > 14) {
                c[index[i]].img_front.setImageResource(imgID[i - 15]);
                c[index[i]].setTag(i-15);
                // 두장의 그림이 한 쌍을 이루어야 하므로 나머지 1/2은 동일한 태그 설정
            }
            else{
                c[index[i]].img_front.setImageResource(imgID[i]);
                c[index[i]].setTag(i);
                // 각 카드의 태그값을 설정
            }
        }

    }

    public void isMatch(final Card [] card) {

        final ImageView FrontID_1 = card[open_card].img_front;
        final ImageView BackID_1 = card[open_card].img_back;
        final ImageView FrontID_2 = card[chk_card].img_front;
        final ImageView BackID_2 = card[chk_card].img_back;

        if (card[open_card].getTag() == card[chk_card].getTag()) {
            // 매치가 될 경우
            Toast.makeText(this,
                    "맞췄습니다.", Toast.LENGTH_SHORT).show();
            open_cnt =0;
            card[open_card].card_state = 2;
            card[chk_card].card_state = 2;
            // 맞춘카드는 항상 오픈 상태로 유지

            FrontID_1.setBackgroundColor(Color.BLUE);
            FrontID_2.setBackgroundColor(Color.BLUE);
            //오픈된 카드는 구분하기위해 배경색 변경
        }

        else {
            //틀릴경우
            // 오픈된 카드의 카운트를 0 으로초기화하고
            card[open_card].card_state = 0;
            card[chk_card].card_state = 0;
            // 오픈된 카드의 상태를 모두 뒤집어진 상태로 변경

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    // 틀린카드를 확인해야하기 때문에 각 카드를 0.8 초간
                    // 보여주고 다시 뒤집는다.
                    FrontID_1.animate()
                            .rotationY(180)
                            .setDuration(500)
                            .setListener(new AnimatorListenerAdapter() {
                                @Override
                                public void onAnimationEnd(Animator animation) {
                                    super.onAnimationEnd(animation);
                                    FrontID_1.setVisibility(View.INVISIBLE);
                                    BackID_1.animate()
                                            .rotationY(360)
                                            .setDuration(500)
                                            .setListener(new AnimatorListenerAdapter() {
                                                @Override
                                                public void onAnimationEnd(Animator animation) {
                                                    super.onAnimationEnd(animation);
                                                    BackID_1.setVisibility(View.VISIBLE);
                                                }
                                            }).start();
                                }
                            })
                            .start();
                    FrontID_2.animate()
                            .rotationY(180)
                            .setDuration(500)
                            .setListener(new AnimatorListenerAdapter() {
                                @Override
                                public void onAnimationEnd(Animator animation) {
                                    super.onAnimationEnd(animation);
                                    FrontID_2.setVisibility(View.INVISIBLE);
                                    BackID_2.animate()
                                            .rotationY(360)
                                            .setDuration(500)
                                            .setListener(new AnimatorListenerAdapter() {
                                        @Override
                                        public void onAnimationEnd(Animator animation) {
                                            super.onAnimationEnd(animation);
                                            BackID_2.setVisibility(View.VISIBLE);
                                        }
                                    }).start();

                                }
                            })
                            .start();
                    open_cnt = 0;
                }
            },800);
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Card [] card = new Card[30];
        final Handler handler = new Handler();
        ImageView.OnClickListener onClickListener = new View.OnClickListener() {
            @Override
            public void onClick(final View v) {

                if(open_cnt >= 2 )
                // 카드가 1장 이상 뒤집어져 있거나
                // 2장이상의 카드를 뒤집으려고 시도하면
                {
                    Toast.makeText(MainActivity.this,
                            "반칙입니다. 2초간 얼립니다.", Toast.LENGTH_SHORT).show();

                    getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {

                            open_cnt=0;
                            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
                        }
                    },2000);

                }

               if(open_cnt==1 || open_cnt ==0){
                    // 카드가 1장도 뒤집어져 있지 않거나,
                    // 1장만 뒤집어져 있을 때
                    // 즉 cnt 값이 0 이거나 1 일 때
                   int index = 0;
                   final ImageView tmp = findViewById(v.getId());
                   // 뒷면 카드의 ID값을 받아서
                   ImageView tmp3 = findViewById(v.getId());
                    for (int i = 0; i < 30; i++) {
                        if (tmp == card[i].img_back || tmp == card[i].img_front) {
                            index = i;
                            // 터치한 뒷면카드의 ID 값과 일치하는
                            // 뒷면 카드ID를 가진 card 배열의
                            // 인덱스를 임시변수 index 에 저장한다.
                            break;
                        }
                    }
                    final ImageView front  = card[index].img_front;
                    final ImageView back = card[index].img_back;
                    // 내부클래스에서 참조 할 final 변수에 값 저장
                    switch (card[index].card_state) {

                        case 0:
                            // 클로즈 상태 일때 오픈
                            if (open_cnt == 0) {
                                open_card = index;
                                card[index].img_back.animate()
                                        .rotationY(180)
                                        .setDuration(500)
                                        .setListener(new AnimatorListenerAdapter() {
                                            @Override
                                            public void onAnimationEnd(Animator animation) {
                                                super.onAnimationEnd(animation);
                                                card[open_card].img_front.setVisibility(View.VISIBLE);
                                                card[open_card].img_back.setVisibility(View.INVISIBLE);
                                            }
                                        }).start();
                                card[index].card_state = 1;
                                // 해당 카드의 상태를 변경하고
                                // 0 일땐 현재 오픈된 카드가 없는 상태이므로
                                // 오픈한 카드의 카운트를 올린다
                                open_cnt++;

                            } else if (open_cnt == 1) {
                                chk_card = index;
                                // 확인할 카드의 인덱스 값을 전역변수에 저장
                                card[index].img_back.animate()
                                        .rotationY(180)
                                        .setDuration(500)
                                        .setListener(new AnimatorListenerAdapter() {
                                            @Override
                                            public void onAnimationEnd(Animator animation) {
                                                super.onAnimationEnd(animation);
                                                card[chk_card].img_front.setVisibility(View.VISIBLE);
                                                card[chk_card].img_back.setVisibility(View.INVISIBLE);
                                            }
                                        }).start();
                                card[index].card_state = 1;
                                open_cnt++;
                                // 카드 하나를 뒤집어 두었을때
                                // 0 이 아닐때는 현재 맞출 카드를 오픈한 상태 이므로
                                // 이전에 선택한 카드와 현재 선택한 카드가 매치가 되는지
                                // 확인한다.
                                isMatch(card);

                            }
                            break;

                        case 1:
                            // 오픈되어 있는 상태 일때
                            // 이미 오픈된 카드를 다시 선택시에는 번복할 수 없다는 경고를 출력한다.
                            Toast.makeText(MainActivity.this,
                                    "선택한 카드는 뒤집을 수 없습니다.", Toast.LENGTH_SHORT).show();
                            break;

                        case 2:
                            Toast.makeText(MainActivity.this,
                                    "이미 매칭된 카드입니다.", Toast.LENGTH_SHORT).show();
                            break;
                    }
                }
            }
        };

        for (int i=0; i<30; i++)
        {
            String ImgName = "img"+i;
            String BackName = "back" +i;
            int ID_front = getResources().getIdentifier(ImgName, "id" ,getPackageName());
            int ID_back =  getResources().getIdentifier(BackName, "id" ,getPackageName());
            ImageView tmp = findViewById(ID_front);
            ImageView tmp2 = findViewById(ID_back);
            card[i] =  new Card(tmp,tmp2, i);
            findViewById(ID_front).setOnClickListener(onClickListener);
            findViewById(ID_back).setOnClickListener(onClickListener);
        }
        shuffle(card);
    }
}
