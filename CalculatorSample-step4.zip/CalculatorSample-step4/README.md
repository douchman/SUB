# CalculatorSample #
Calculator Sample for android

### Branches ###
#### - master: Basic code ####
#### - step1: Full code and Event Listener ####
#### - step2: Refactoring code ####
#### - step2_1: Other code ####
#### - step3: Actual calculation ####
#### * step4: Postfix notation ####
#### - step5: Creating Dynamic UI ####